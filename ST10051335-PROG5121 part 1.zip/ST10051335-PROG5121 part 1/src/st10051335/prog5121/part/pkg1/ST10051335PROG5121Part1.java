package st10051335.prog5121.part.pkg1;
import java.util.Scanner;


public class ST10051335PROG5121Part1 {
    
   
    public static void main(String[] args) {
      Login LoginFrame = new Login();
      LoginFrame.setVisible(true);
      LoginFrame.pack();
      LoginFrame.setLocationRelativeTo(LoginFrame);
     
            try (Scanner scanner = new Scanner(System.in)) {
            System.out.print(" Enter user name => ");
            String userName = scanner.nextLine();

            System.out.print(" Enter password => ");
            String password = scanner.nextLine();

            if ("Tyrique_".equals(userName) && "Tyrique031#".equals(password)) {
                System.out.println(" Welcome Tyrique, it's great to see you!");
            } else {
                System.out.println(" Username must contain an underscore and password must be more than 8 characters long and contain a capital,number and special character ");
            }
        }
    }
}

     
     
     
    
      
          
      
    

    